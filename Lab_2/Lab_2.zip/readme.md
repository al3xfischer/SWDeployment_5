Node-App Code:
https://github.com/al3xfischer/node-app-swd.git

Test Website:
https://fhwn19-node-af.azurewebsites.net

Production Website:
https://fhwn19-node-prod-af.azurewebsites.net


Ein Release muss durch einen ausgewählten Benutzer freigegeben werden. (Siehe Release_Trigger.png)
Der autorisierte Benutzer kann im "dev.azure.com" Portal im entsprechenden
Projekt unter Releases mit "Create release" eine neue Version veröffentlichen.
Dazu muss ein Build gewählt werden und optional eine Beschreibung eingegeben werden.